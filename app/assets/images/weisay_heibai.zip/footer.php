<div class="clear"></div>
   <div class="footer">
    <div class="resize">
      <div class="text_left"><li><a title="返回首页" href="<?php echo get_settings('Home'); ?>/">Home</a></li><?php wp_list_categories("orderby=name&depth=1&title_li=&exclude="); ?><?php wp_list_pages('sort_columu=&depth=-1&title_li='); ?></div>
      <div>Copyright <?php echo comicpress_copyright(); ?> <?php bloginfo('name'); ?> All rights reserved. Design by <a href="http://www.weisay.com/">Weisay</a><br>
        <?php if (get_option('swt_beian') == 'Display') { ?><a href="http://www.miitbeian.gov.cn/" rel="external"><?php echo stripslashes(get_option('swt_beianhao')); ?></a><?php { echo ''; } ?><?php } else { } ?> | <a href="http://www.wordpress.org/" rel="external">WordPress</a> | <?php if (get_option('swt_tj') == 'Display') { ?><?php echo stripslashes(get_option('swt_tjcode')); ?><?php { echo ''; } ?>
	<?php } else { } ?></div>
    </div><?php wp_footer(); ?>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>