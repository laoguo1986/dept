<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">

                <div class="content_l"><?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="left">
<div class="post_date"><span class="date_m"><?php echo date('M',get_the_time('U'));?></span><span class="date_d"><?php the_time('d') ?></span><span class="date_y"><?php the_time('Y') ?></span></div>
<div class="article">
<div class="article_t">
<div class="article_b"><h2 class="entry-title _cf"><?php the_title(); ?></h2>
        <div class="context"><p><?php the_content('Read more...'); ?></p>
        <div class="clear"></div>
				<?php the_tags('标签: ', ', ', ' '); ?>
				<span class="edit"><?php edit_post_link('编辑', ' [ ', ' ] '); ?></span>
        </div>
</div>

<div class="article_ff">
</div></div>
</div></div>

<div class="left">
<div class="article">
<div class="article_t">
<div class="article_b">
<?php comments_template(); ?>

</div>
<div class="article_ff">
</div></div>
</div></div>

	<?php endwhile; else: ?>
	<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>