<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="转到底部" id="fall"></div></div>
	<div id="content">
    <div class="content_l">
<div class="left">
<div class="article">
<div class="article_t">
<div class="article_b">
<h4>抱歉，您打开的页面未能找到。<br /><br />您可以使用本站的搜索框搜索您想要的内容，如有不便深感抱歉！</h4>
</div>
<div class="article_ff">
</div></div>
</div></div>

</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>
